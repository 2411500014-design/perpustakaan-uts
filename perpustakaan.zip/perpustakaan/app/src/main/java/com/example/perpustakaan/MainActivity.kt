package com.example.perpustakaan

import android.os.Bundle
import android.os.StrictMode
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var id_buku: TextView

    private val BASE_URL = "http://10.19.225.63/api.buku.php"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        id_buku = findViewById(R.id.id_buku)

        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder().permitAll().build()
        )

        getBukuByID(id = 1)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun getBukuByID(id: Int) {
        try {
            val url = URL("$BASE_URL?id=$id")
            val con = url.openConnection() as HttpURLConnection
            con.requestMethod = "GET"

            val reader = BufferedReader(InputStreamReader(con.inputStream))
            val sb = StringBuilder()
            var line: String?

            while (reader.readLine().also { line = it } != null) {
                sb.append(line)
            }

            val json = JSONObject(sb.toString())
            val buku = json.getJSONObject("data")
            val result = StringBuilder()
            result.append("ID ${buku.getInt("id_buku")}\n")
            result.append("Judul ${buku.getString("judul")}\n")
            result.append("Penulis ${buku.getString("penulis")}\n")
            result.append("Penerbit ${buku.getString("penerbit")}\n")
            result.append("Tahun Terbit ${buku.getInt("tahun_terbit")}\n")
            result.append("Kategori ${buku.getString("kategori")}\n")
            result.append("Cover ${buku.getString("cover_buku")}\n")

            id_buku.text = result.toString()

        } catch (e: Exception) {
            id_buku.text = "Error: ${e.message}"
        }
    }
}